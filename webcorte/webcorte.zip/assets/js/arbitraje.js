// Año footer
const y = document.getElementById("year");
if (y) y.textContent = new Date().getFullYear();

// Menú móvil (tu burger)
const burger = document.getElementById("burger");
const mobileMenu = document.getElementById("mobileMenu");

function toggleMenu() {
  document.body.classList.toggle("menu-open");
}
burger?.addEventListener("click", toggleMenu);

// Cierra menú al hacer click en un link del mobile
mobileMenu?.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => document.body.classList.remove("menu-open"));
});

// Copiar cláusula
const copyBtn = document.getElementById("copyClause");
const clauseText = document.getElementById("clauseText");

copyBtn?.addEventListener("click", async () => {
  try{
    const text = clauseText?.innerText?.trim() || "";
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = "✅ Copiado";
    setTimeout(() => (copyBtn.textContent = "Copiar cláusula"), 1400);
  }catch(e){
    alert("No se pudo copiar. Selecciona el texto y copia manualmente.");
  }
});

// Tabs reglamentos
document.querySelectorAll("[data-tabs]").forEach((wrap) => {
  const tabs = wrap.querySelectorAll(".tab");
  const panes = wrap.querySelectorAll(".pane");

  function show(id){
    tabs.forEach(t => {
      const on = t.dataset.tab === id;
      t.classList.toggle("active", on);
      t.setAttribute("aria-selected", on ? "true" : "false");
    });
    panes.forEach(p => p.classList.toggle("show", p.id === id));
  }

  tabs.forEach(t => t.addEventListener("click", () => show(t.dataset.tab)));
});

// Reveal on scroll
const io = new IntersectionObserver((entries)=>{
  entries.forEach(en => { if(en.isIntersecting) en.target.classList.add("show"); });
},{threshold:0.12});

document.querySelectorAll(".reveal").forEach(el => io.observe(el));
