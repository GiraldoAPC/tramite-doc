<?php /* arbitraje.php */ ?>
<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Arbitraje | Corte Superior de Arbitraje – CCITA</title>

    <link rel="stylesheet" href="assets/css/arbitraje.css" />
    <link rel="stylesheet" href="assets/css/index.css" />
</head>

<body>

    <!-- Top bar -->
    <div class="topbar">
        <div class="container">
            <div class="inner">
                <div class="meta">
                    <span class="pill">Jr. José de Sucre 765 - 3er Piso, Huaraz - Áncash</span>
                    <span class="pill">☎ 972 495 162</span>
                    <span class="pill">✉ secretariageneralcaa@camaradeancash.org.pe</span>
                </div>
                <div class="pill">Corte Superior de Arbitraje – CCITA</div>
            </div>
        </div>
    </div>

    <!-- Header / Nav -->
    <header>
        <div class="container">
            <div class="nav">
                <a class="brand" href="#inicio" aria-label="Inicio">
                    <div class="logo">
                        <!-- Reemplaza logo.png por tu logo real -->
                        <img src="LOGOCORTE.png" alt="Logo Corte de Arbitraje" onerror="this.style.display='none';this.parentElement.textContent='CA';" />
                    </div>
                    <div class="txt">
                        <div class="t1">Corte Superior de Arbitraje</div>
                        <div class="t2">Cámara de Comercio de Áncash</div>
                    </div>
                </a>

                <nav aria-label="Navegación principal">
                    <ul>
                        <li><a href="#nosotros">Nosotros</a></li>
                        <li><a href="organizacion.php">Organización</a></li>
                        <li><a href="#arbitraje">Arbitraje</a></li>
                        <li><a href="#reglamentos">Reglamentos</a></li>
                        <li><a href="#sig">Sistema Integrado</a></li>
                        <li><a href="#contacto">Contacto</a></li>
                    </ul>
                </nav>

                <div class="actions">
                    <a class="btn btn-outline" href="#reglamentos">Ver reglamentos</a>
                    <a class="btn btn-primary" href="#arbitraje">Ingresar</a>

                    <button class="burger" id="burger" aria-label="Abrir menú">
                        <span></span>
                    </button>
                </div>
            </div>

            <!-- Mobile menu -->
            <div class="mobile" id="mobileMenu">
                <a href="#nosotros">Nosotros</a>
                <a href="#organizacion">Organización</a>
                <a href="#arbitraje">Arbitraje</a>
                <a href="#reglamentos">Reglamentos</a>
                <a href="#sig">Sistema Integrado</a>
                <a href="#contacto">Contacto</a>
            </div>
        </div>
    </header>
    <!-- ====== /TU HEADER ====== -->

    <!-- ===== HERO ===== -->
    <section class="hero" id="inicio">
        <div class="hero-bg" style="background-image:url('assets/img/hero-arbitraje.jpg')"></div>
        <div class="hero-overlay"></div>

        <div class="container hero-inner">
            <div class="crumbs reveal">
                <a href="index.php">Inicio</a> <span class="sep">/</span> <span>Arbitraje</span>
            </div>

            <h1 class="reveal">Arbitraje</h1>
            <p class="lead reveal">
                Accede a solicitudes, escritos, revisión de expedientes, reglamentos, nómina de árbitros,
                tarifario virtual y documentación institucional.
            </p>

            <div class="hero-actions reveal">
                <a class="btn btn-primary" href="#accesos">Accesos rápidos</a>
                <a class="btn btn-outline" href="#clausula">Cláusula arbitral</a>
            </div>
        </div>

        <div class="wave" aria-hidden="true">
            <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path d="M0,80 C240,120 480,20 720,60 C960,100 1200,40 1440,70 L1440,120 L0,120 Z"></path>
            </svg>
        </div>
    </section>

    <!-- ===== ACCESOS RÁPIDOS ===== -->
    <section class="section" id="accesos">
        <div class="container">
            <div class="section-head reveal">
                <h2>Accesos rápidos</h2>
                <p>Selecciona la opción que necesitas. Puedes enlazar cada botón a tu sistema o archivos PDF.</p>
            </div>

            <div class="quick-grid">
                <a class="qcard reveal" href="#ingreso">
                    <div class="qicon"></div>
                    <b>Ingreso de solicitudes</b>
                    <span>Crear una cuenta para ingresar documentos.</span>
                    <em>Ir</em>
                </a>

                <a class="qcard reveal" href="#escritos">
                    <div class="qicon"></div>
                    <b>Ingreso de escritos</b>
                    <span>Presentación de escritos y anexos.</span>
                    <em>Ir</em>
                </a>

                <a class="qcard reveal" href="#expedientes">
                    <div class="qicon"></div>
                    <b>Revisión de expedientes</b>
                    <span>Consulta de estado y seguimiento.</span>
                    <em>Ir</em>
                </a>

                <a class="qcard reveal" href="#clausula">
                    <div class="qicon"></div>
                    <b>Cláusula arbitral</b>
                    <span>Texto oficial para contratos y actos jurídicos.</span>
                    <em>Ver</em>
                </a>

                <a class="qcard reveal" href="#reglamentos">
                    <div class="qicon"></div>
                    <b>Reglamentos</b>
                    <span>Vigente 05/03/2025, 2015, ética, estatuto, etc.</span>
                    <em>Ver</em>
                </a>

                <a class="qcard reveal" href="#arbitros">
                    <div class="qicon"></div>
                    <b>Árbitros (Nómina)</b>
                    <span>Listado actualizado de árbitros.</span>
                    <em>Ver</em>
                </a>

                <a class="qcard reveal" href="#tarifario">
                    <div class="qicon"></div>
                    <b>Tarifario virtual</b>
                    <span>Calculadora virtual de tarifas.</span>
                    <em>Calcular</em>
                </a>

                <a class="qcard reveal" href="#incorporacion">
                    <div class="qicon"></div>
                    <b>Solicitud de incorporación</b>
                    <span>Directiva y ficha de inscripción.</span>
                    <em>Ver</em>
                </a>

                <a class="qcard reveal" href="#comunicados">
                    <div class="qicon"></div>
                    <b>Comunicados</b>
                    <span>Información institucional y avisos.</span>
                    <em>Ver</em>
                </a>
            </div>
        </div>
    </section>

    <!-- ===== INGRESO (3 tarjetas grandes como tu home) ===== -->
    <section class="section soft" id="ingreso">
        <div class="container">
            <div class="section-head reveal">
                <h2>Plataforma de Arbitraje</h2>
                <p>Entradas principales para usuarios. Enlaza a tu sistema cuando lo tengas listo.</p>
            </div>

            <div class="tri-grid">
                <div class="big-card reveal">
                    <div class="big-top">
                        <b>Ingreso de solicitudes</b>
                        <span>Crea una cuenta y registra tus documentos.</span>
                    </div>
                    <div class="big-actions">
                        <a class="btn btn-primary" href="#">Crear cuenta</a>
                        <a class="btn btn-outline" href="#">Ingresar</a>
                    </div>
                </div>

                <div class="big-card reveal" id="escritos">
                    <div class="big-top">
                        <b>Ingreso de escritos</b>
                        <span>Presenta escritos, anexos y comunicaciones.</span>
                    </div>
                    <div class="big-actions">
                        <a class="btn btn-primary" href="#">Ingresar escritos</a>
                        <a class="btn btn-outline" href="#">Guía</a>
                    </div>
                </div>

                <div class="big-card reveal" id="expedientes">
                    <div class="big-top">
                        <b>Revisión de expedientes</b>
                        <span>Consulta el estado de tu expediente y seguimiento.</span>
                    </div>
                    <div class="big-actions">
                        <a class="btn btn-primary" href="#">Consultar</a>
                        <a class="btn btn-outline" href="#">Ayuda</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CLÁUSULA ARBITRAL ===== -->
    <section class="section" id="clausula">
        <div class="container">
            <div class="clause reveal">
                <div class="clause-left">
                    <h2>Cláusula arbitral</h2>
                    <p>Texto oficial para incluir en contratos o actos jurídicos:</p>

                    <blockquote id="clauseText">
                        “Todo litigio o controversia derivados o relacionados con este acto jurídico, será resuelto
                        mediante arbitraje de conformidad con los reglamentos arbitrales de la Corte de Arbitraje
                        de la Cámara de Comercio, Industria y Turismo de Ancash, a cuyas normas, administración
                        y decisión se someten las partes y las aceptan en su integridad”.
                    </blockquote>

                    <div class="clause-actions">
                        <button class="btn btn-primary" id="copyClause">Copiar cláusula</button>
                        <a class="btn btn-outline" href="#reglamentos">Ver reglamento</a>
                    </div>
                </div>

                <div class="clause-right">
                    <div class="glass">
                        <b>Recomendación</b>
                        <p>
                            Antes de usar la cláusula, confirma el reglamento vigente y la versión aplicable
                            según el tipo de contrato y el periodo.
                        </p>
                        <div class="mini">
                            <span class="tag">Vigente 05/03/2025</span>
                            <span class="tag">Código de ética</span>
                            <span class="tag">Decreto Legislativo 1071</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== REGLAMENTOS (TABS PRO) ===== -->
    <section class="section soft" id="reglamentos">
        <div class="container">
            <div class="section-head reveal">
                <h2>Reglamentos y documentos</h2>
                <p>Organizado por categorías. Enlaza cada item a tus PDF cuando los tengas.</p>
            </div>

            <div class="tabs reveal" data-tabs>
                <div class="tabbar" role="tablist" aria-label="Reglamentos">
                    <button class="tab active" type="button" role="tab" aria-selected="true" data-tab="t1">Reglamentos</button>
                    <button class="tab" type="button" role="tab" aria-selected="false" data-tab="t2">Normativa</button>
                    <button class="tab" type="button" role="tab" aria-selected="false" data-tab="t3">Guías</button>
                </div>

                <div class="tabpanes">
                    <div class="pane show" id="t1" role="tabpanel">
                        <a class="doc" href="#">
                            <b>Reglamento vigente (05/03/2025)</b>
                            <span>Documento principal vigente.</span>
                            <em>PDF</em>
                        </a>
                        <a class="doc" href="#">
                            <b>Reglamento antiguo (2015)</b>
                            <span>Versión histórica.</span>
                            <em>PDF</em>
                        </a>
                        <a class="doc" href="#">
                            <b>Código de ética</b>
                            <span>Principios y conducta.</span>
                            <em>PDF</em>
                        </a>
                        <a class="doc" href="#">
                            <b>Estatuto</b>
                            <span>Marco institucional.</span>
                            <em>PDF</em>
                        </a>
                    </div>

                    <div class="pane" id="t2" role="tabpanel">
                        <a class="doc" href="#">
                            <b>Directiva N°01-2020</b>
                            <span>Lineamientos y disposiciones.</span>
                            <em>PDF</em>
                        </a>
                        <a class="doc" href="#">
                            <b>Reglamento Ley N° 32069</b>
                            <span>Ley General de Contrataciones Públicas.</span>
                            <em>PDF</em>
                        </a>
                        <a class="doc" href="#">
                            <b>Decreto Legislativo N° 1071</b>
                            <span>Norma que regula el arbitraje.</span>
                            <em>PDF</em>
                        </a>
                    </div>

                    <div class="pane" id="t3" role="tabpanel">
                        <a class="doc" href="#">
                            <b>Guía virtual</b>
                            <span>Orientación para usuarios.</span>
                            <em>PDF</em>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== ÁRBITROS / TARIFARIO / INCORPORACIÓN / COMUNICADOS ===== -->
    <section class="section" id="arbitros">
        <div class="container">
            <div class="two-grid">
                <div class="panel reveal">
                    <h2>Árbitros (Nómina)</h2>
                    <p>Acceso al listado actualizado de árbitros.</p>
                    <div class="panel-actions">
                        <a class="btn btn-primary" href="#">Ver nómina</a>
                        <a class="btn btn-outline" href="#">Descargar PDF</a>
                    </div>
                </div>

                <div class="panel reveal" id="tarifario">
                    <h2>Tarifario virtual</h2>
                    <p>Calculadora virtual para estimar tarifas.</p>
                    <div class="panel-actions">
                        <a class="btn btn-primary" href="#">Abrir calculadora</a>
                        <a class="btn btn-outline" href="#">Ver tarifario</a>
                    </div>
                </div>

                <div class="panel reveal" id="incorporacion">
                    <h2>Solicitud de incorporación</h2>
                    <p>Directiva y ficha de inscripción para postulación.</p>
                    <div class="panel-actions">
                        <a class="btn btn-primary" href="#">Ver directiva</a>
                        <a class="btn btn-outline" href="#">Ficha de inscripción</a>
                    </div>
                </div>

                <div class="panel reveal" id="comunicados">
                    <h2>Comunicados</h2>
                    <p>Publicaciones institucionales y avisos importantes.</p>
                    <div class="panel-actions">
                        <a class="btn btn-primary" href="#">Ver comunicados</a>
                        <a class="btn btn-outline" href="#">Suscribirme</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ====== TU FOOTER OFICIAL (SIN CAMBIOS) ====== -->
    <footer>
        <div class="container">
            <div class="foot">
                <div style="display:flex; align-items:center; gap:10px">
                    <span style="width:10px;height:10px;border-radius:3px;background:linear-gradient(135deg,var(--red-600),var(--orange-500));display:inline-block"></span>
                    <span>© <span id="year"></span> Corte Superior de Arbitraje – CCITA</span>
                </div>
                <div>Desing by GIRALDO</div>
            </div>
        </div>
    </footer>

    <script src="assets/js/arbitraje.js"></script>
</body>

</html>