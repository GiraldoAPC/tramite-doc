<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Organización | Corte Superior de Arbitraje</title>

    <!-- CSS -->
    
    <link rel="stylesheet" href="assets/css/index.css" />

    <!-- Favicon opcional -->
    <link rel="icon" href="assets/img/favicon.png" />
</head>

<body>
    <!-- Top bar -->
    <div class="topbar">
        <div class="container">
            <div class="inner">
                <div class="meta">
                    <span class="pill">Jr. José de Sucre 765 - 3er Piso, Huaraz - Áncash</span>
                    <span class="pill">☎ 972 495 162</span>
                    <span class="pill">✉ secretariageneralcaa@camaradeancash.org.pe</span>
                </div>
                <div class="pill">Corte Superior de Arbitraje – CCITA</div>
            </div>
        </div>
    </div>

    <!-- Header / Nav -->
    <header>
        <div class="container">
            <div class="nav">
                <a class="brand" href="#inicio" aria-label="Inicio">
                    <div class="logo">
                        <!-- Reemplaza logo.png por tu logo real -->
                        <img src="LOGOCORTE.png" alt="Logo Corte de Arbitraje" onerror="this.style.display='none';this.parentElement.textContent='CA';" />
                    </div>
                    <div class="txt">
                        <div class="t1">Corte Superior de Arbitraje</div>
                        <div class="t2">Cámara de Comercio de Áncash</div>
                    </div>
                </a>

                <nav aria-label="Navegación principal">
                    <ul>
                        <li><a href="index.php">Nosotros</a></li>
                        <li><a href="/organizacion.php">Organización</a></li>
                        <li><a href="#arbitraje">Arbitraje</a></li>
                        <li><a href="#reglamentos">Reglamentos</a></li>
                        <li><a href="#sig">Sistema Integrado</a></li>
                        <li><a href="#contacto">Contacto</a></li>
                    </ul>
                </nav>

                <div class="actions">
                    <a class="btn btn-outline" href="#reglamentos">Ver reglamentos</a>
                    <a class="btn btn-primary" href="#arbitraje">Ingresar</a>

                    <button class="burger" id="burger" aria-label="Abrir menú">
                        <span></span>
                    </button>
                </div>
            </div>

            <!-- Mobile menu -->
            <div class="mobile" id="mobileMenu">
                <a href="#nosotros">Nosotros</a>
                <a href="#organizacion">Organización</a>
                <a href="#arbitraje">Arbitraje</a>
                <a href="#reglamentos">Reglamentos</a>
                <a href="#sig">Sistema Integrado</a>
                <a href="#contacto">Contacto</a>
            </div>
        </div>
    </header>

    <!-- HERO -->
    <section class="hero">
        <div class="hero-bg" style="background-image:url('assets/img/fondocorte.jpg')"></div>
        <div class="hero-overlay"></div>

        <div class="container hero-inner">
            <div class="breadcrumb reveal">
                <a href="index.html">Inicio</a> <span class="sep">/</span> <span>Organización</span>
            </div>

            <h1 class="reveal">Organización</h1>
            <p class="hero-sub reveal">
                Conoce el Consejo Superior y el equipo administrativo que garantiza una
                gestión <b>eficiente</b>, <b>transparente</b> y alineada al marco normativo vigente.
            </p>

            <div class="hero-actions reveal">
                <a class="btn btn-primary" href="#consejo">Ver Consejo Superior</a>
                <a class="btn btn-ghost" href="#secretaria">Secretaría General</a>
            </div>
        </div>

        <div class="hero-wave" aria-hidden="true">
            <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path d="M0,80 C240,120 480,20 720,60 C960,100 1200,40 1440,70 L1440,120 L0,120 Z"></path>
            </svg>
        </div>
    </section>

    <!-- Organización -->
    <section id="organizacion">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Organización</h2>
                    <p>Consejo Superior de la Corte de Arbitraje y Secretaría General.</p>
                </div>
            </div>

            <div class="card" style="margin-bottom:16px">
                <h3>Consejo Superior de Arbitraje</h3>
                <p class="muted">
                    Conformado por profesionales con amplio conocimiento de la Ley de Arbitraje y reglamentos aplicables.
                    Su misión es asegurar la correcta aplicación del Reglamento y el marco normativo vigente, garantizando una administración adecuada, eficiente y transparente. :contentReference[oaicite:5]{index=5}
                </p>

                <div class="people" aria-label="Miembros del Consejo Superior">
                    <div class="person">
                        <div class="ph">FOTO</div>
                        <div class="pbody">
                            <div class="pname">Dr. Juan Hugo Villar Ñañez</div>
                            <div class="prole">(Presidente)</div>
                        </div>
                    </div>
                    <div class="person">
                        <div class="ph">FOTO</div>
                        <div class="pbody">
                            <div class="pname">Dr. Felix Claudio Julca Guerrero</div>
                            <div class="prole">(Vicepresidente)</div>
                        </div>
                    </div>
                    <div class="person">
                        <div class="ph">FOTO</div>
                        <div class="pbody">
                            <div class="pname">Ing. Luis Francisco Díaz Padilla</div>
                            <div class="prole">(Consejero)</div>
                        </div>
                    </div>
                    <div class="person">
                        <div class="ph">FOTO</div>
                        <div class="pbody">
                            <div class="pname">Ing. Elena Milagros Ríos Ortiz</div>
                            <div class="prole">(Consejero)</div>
                        </div>
                    </div>
                    <div class="person">
                        <div class="ph">FOTO</div>
                        <div class="pbody">
                            <div class="pname">Dr. Ricardo Augusto Maldonado Vergara</div>
                            <div class="prole">(Consejero)</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid-2">
                <div class="card">
                    <h3>Secretaría General</h3>
                    <p class="muted">
                        Autoridad administrativa responsable de la gestión y administración de la Corte, y del cumplimiento de los acuerdos del Consejo Superior.
                    </p>
                    <ul class="list">
                        <li><span class="dot"></span>
                            <div><b>Responsable:</b> Dra. María del Carmen Segura Córdova. </div>
                        </li>
                        <li><span class="dot"></span>
                            <div>Experiencia en mecanismos alternativos de solución de controversias y fortalecimiento institucional.</div>
                        </li>
                    </ul>
                </div>

                <div class="card">
                    <h3>Secretarías arbitrales y personal administrativo</h3>
                    <p class="muted">
                        Asisten a los árbitros en los procesos arbitrales. :contentReference[oaicite:9]{index=9}
                    </p>
                    <div class="people" style="grid-template-columns:repeat(2,1fr)">
                        <div class="person">
                            <div class="ph">FOTO</div>
                            <div class="pbody">
                                <div class="pname">Dra. María del Carmen Segura Córdova</div>
                                <div class="prole">Secretaría General</div>
                            </div>
                        </div>
                        <div class="person">
                            <div class="ph">FOTO</div>
                            <div class="pbody">
                                <div class="pname">xxxxx</div>
                                <div class="prole">Secretaría / Administrativo</div>
                            </div>
                        </div>
                    </div>
                    <p class="muted" style="margin-top:12px; font-size:13px;">
                        ..............
                    </p>
                </div>
            </div>
        </div>
    </section>


    <!-- FOOTER -->
    <footer class="footer">
        <div class="container footer-inner">
            <div class="footer-brand">
                <img src="assets/img/logo.png" alt="Logo" />
                <div>
                    <b>Corte Superior de Arbitraje</b>
                    <span>Cámara de Comercio de Áncash</span>
                </div>
            </div>

            <div class="footer-copy">
                © <span id="year"></span> Corte Superior de Arbitraje – CCITA. Todos los derechos reservados.
            </div>
        </div>
    </footer>

    <!-- JS -->
    <script src="assets/js/organizacion.js"></script>
</body>

</html>