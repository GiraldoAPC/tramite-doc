<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Corte Superior de Arbitraje - Cámara de Comercio de Áncash</title>
    <meta name="description" content="Corte de Arbitraje de la Cámara de Comercio, Industria y Turismo de Áncash (CCITA)." />

    <!-- Tipografía -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            /* Paleta inspirada en el logo */
            --red-600: #DB2328;
            --red-800: #B41F23;
            --orange-500: #FAA31A;

            --gray-900: #121212;
            --gray-800: #1B1B1B;
            --gray-700: #2A2A2A;
            --gray-600: #4B4B4B;
            --gray-500: #71706E;
            --gray-200: #E9E9E9;
            --gray-100: #F5F5F5;
            --white: #ffffff;

            --radius-xl: 18px;
            --radius-lg: 14px;
            --radius-md: 12px;

            --shadow-sm: 0 10px 28px rgba(0, 0, 0, .08);
            --shadow-md: 0 18px 42px rgba(0, 0, 0, .12);

            --container: 1440px;

            /* Ajusta si tu topbar+header cambia */
            --header-total: 124px;
        }

        * {
            box-sizing: border-box
        }

        html,
        body {
            height: 100%
        }

        body {
            margin: 0;
            font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Arial, sans-serif;
            color: var(--gray-900);
            background:
                radial-gradient(1200px 500px at 20% -10%, rgba(250, 163, 26, .18), transparent 55%),
                radial-gradient(1000px 520px at 95% 0%, rgba(219, 35, 40, .12), transparent 60%),
                #fff;
            line-height: 1.55;
            -webkit-font-smoothing: antialiased;
            text-rendering: geometricPrecision;
        }

        a {
            color: inherit;
            text-decoration: none
        }

        img {
            max-width: 100%;
            display: block
        }

        .container {
            width: min(var(--container), calc(100% - 10px));
            margin: 0 auto;
        }

        /* ---------------- TOPBAR ---------------- */
        .topbar {
            background: linear-gradient(90deg, var(--red-800), var(--red-600));
            color: #fff;
            font-size: 13px;
        }

        .topbar .inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 10px 0;
        }

        .topbar .meta {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            opacity: .95;
        }

        .pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 999px;
            background: rgba(255, 255, 255, .12);
            border: 1px solid rgba(255, 255, 255, .18);
            white-space: nowrap;
        }

        /* ---------------- HEADER ---------------- */
        header {
            position: sticky;
            top: 0;
            z-index: 50;
            backdrop-filter: saturate(180%) blur(10px);
            background: rgba(255, 255, 255, .85);
            border-bottom: 1px solid rgba(0, 0, 0, .06);
        }

        /* ✅ Header NO crece */
        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding: 10px 0;
            height: 74px;
            /* altura fija */
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 240px;
            height: 100%;
        }

        .brand .logo {
            display: flex;
            align-items: center;
            height: 100%;
            padding: 0;
            margin: 0;
            background: transparent;
            border: 0;
        }

        .brand .logo img {
            height: 62px;
            max-height: 62px;
            width: auto;
            object-fit: contain;
        }

        .brand .txt .t1 {
            font-weight: 800;
            letter-spacing: -.02em
        }

        .brand .txt .t2 {
            font-size: 12px;
            color: var(--gray-600)
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            gap: 16px;
        }

        nav a {
            font-weight: 600;
            font-size: 14px;
            padding: 10px 10px;
            border-radius: 10px;
            color: var(--gray-800);
        }

        nav a:hover {
            background: rgba(0, 0, 0, .05)
        }

        .actions {
            display: flex;
            align-items: center;
            gap: 10px
        }

        /* ---------------- BUTTONS ---------------- */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 12px;
            font-weight: 800;
            border: 1px solid transparent;
            cursor: pointer;
            transition: transform .15s ease, box-shadow .15s ease, background .15s ease, border-color .15s ease, filter .15s ease;
            user-select: none;
            white-space: nowrap;
        }

        .btn:active {
            transform: translateY(1px)
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--red-800), var(--red-600));
            color: #fff;
            box-shadow: 0 12px 24px rgba(219, 35, 40, .18);
        }

        .btn-primary:hover {
            box-shadow: 0 16px 34px rgba(219, 35, 40, .22)
        }

        .btn-accent {
            background: linear-gradient(135deg, #ffb642, var(--orange-500));
            color: #ffffff;
            border-color: rgba(0, 0, 0, .06);
            box-shadow: 0 12px 24px rgba(250, 163, 26, .20);
        }

        .btn-outline {
            background: rgba(255, 255, 255, .92);
            border-color: rgba(0, 0, 0, .10);
            color: #B41F23;
            box-shadow: 0 12px 24px rgba(219, 35, 40, .18);
        }

        .btn-outline:hover {
            background: #fff
        }

        .burger {
            display: none;
            width: 44px;
            height: 44px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, .10);
            background: #fff;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .burger span {
            width: 18px;
            height: 2px;
            background: #222;
            position: relative;
            display: block;
        }

        .burger span:before,
        .burger span:after {
            content: "";
            position: absolute;
            left: 0;
            width: 18px;
            height: 2px;
            background: #222;
        }

        .burger span:before {
            top: -6px
        }

        .burger span:after {
            top: 6px
        }

        /* ---------------- HERO / SLIDER ---------------- */
        .hero {
            min-height: calc(100vh - var(--header-total));
            display: flex;
            align-items: center;
            padding: 28px 0;
        }

        /* ===== SLIDER PRO: crossfade + blur + zoom + light-wipe ===== */
        .hero-slider {
            position: relative;
            min-height: calc(100vh - 120px);
            display: flex;
            align-items: center;
            padding: 28px 0;
            overflow: hidden;
        }

        /* slides */
        .hero-slides {
            position: absolute;
            inset: 0;
            z-index: 0;
            isolation: isolate;
        }

        .hero-slide {
            position: absolute;
            inset: 0;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;

            opacity: 0;
            visibility: hidden;

            transform: scale(1.08);
            filter: blur(8px) saturate(1.15) contrast(1.12);
            transition:
                opacity 1.05s cubic-bezier(.2, .8, .2, 1),
                transform 1.85s cubic-bezier(.2, .8, .2, 1),
                filter 1.35s cubic-bezier(.2, .8, .2, 1);
            will-change: opacity, transform, filter;
        }

        .hero-slide.is-active {
            opacity: 1;
            visibility: visible;
            transform: scale(1.03);
            filter: blur(0px) saturate(1.08) contrast(1.08);
        }

        .hero-slide.is-next {
            opacity: .001;
            visibility: visible;
        }

        .hero-slide::before {
            content: "";
            position: absolute;
            inset: -30% -40%;
            background: linear-gradient(120deg,
                    rgba(255, 255, 255, 0) 35%,
                    rgba(255, 255, 255, .10) 50%,
                    rgba(255, 255, 255, 0) 65%);
            transform: translateX(-35%) rotate(8deg);
            opacity: 0;
            pointer-events: none;
        }

        .hero-slide.is-active::before {
            animation: lightwipe 2.6s ease both;
            opacity: 1;
        }

        @keyframes lightwipe {
            0% {
                transform: translateX(-45%) rotate(8deg);
                opacity: 0;
            }

            18% {
                opacity: .55;
            }

            100% {
                transform: translateX(30%) rotate(8deg);
                opacity: 0;
            }
        }

        .hero-overlay {
            position: absolute;
            inset: 0;
            z-index: 1;
            background:
                radial-gradient(1100px 520px at 20% 30%, rgba(250, 163, 26, .12), transparent 55%),
                radial-gradient(1000px 520px at 85% 40%, rgba(219, 35, 40, .10), transparent 60%),
                radial-gradient(120% 120% at 50% 40%, rgba(0, 0, 0, .18), rgba(0, 0, 0, .58));
            pointer-events: none;
        }

        .hero-slider .container {
            position: relative;
            z-index: 2;
        }

        /* Flechas PRO */
        .hero-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 52px;
            height: 52px;
            border-radius: 999px;
            border: 1px solid rgba(255, 255, 255, .22);
            background: rgba(20, 20, 22, .40);
            backdrop-filter: blur(10px);
            color: rgba(255, 255, 255, .92);
            cursor: pointer;
            z-index: 3;
            display: grid;
            place-items: center;
            font-size: 28px;
            line-height: 1;
            box-shadow: 0 18px 44px rgba(0, 0, 0, .25);
            transition: transform .18s ease, background .18s ease, box-shadow .18s ease, border-color .18s ease, opacity .18s ease;
            opacity: .92;
        }

        .hero-arrow:hover {
            transform: translateY(-50%) scale(1.06);
            background: rgba(20, 20, 22, .55);
            border-color: rgba(255, 255, 255, .35);
            box-shadow: 0 22px 56px rgba(0, 0, 0, .30);
            opacity: 1;
        }

        .hero-arrow:active {
            transform: translateY(-50%) scale(.98)
        }

        .hero-arrow.prev {
            left: 18px
        }

        .hero-arrow.next {
            right: 18px
        }

        /* Dots PRO */
        .hero-dots {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: 14px;
            z-index: 3;
            display: flex;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 999px;
            background: rgba(15, 15, 16, .40);
            border: 1px solid rgba(255, 255, 255, .18);
            backdrop-filter: blur(10px);
            box-shadow: 0 14px 38px rgba(0, 0, 0, .22);
        }

        .hero-dots .dot {
            width: 26px;
            height: 6px;
            border-radius: 999px;
            border: 0;
            cursor: pointer;
            background: rgba(255, 255, 255, .25);
            transition: transform .18s ease, background .18s ease, width .18s ease;
        }

        .hero-dots .dot:hover {
            background: rgba(255, 255, 255, .38);
            transform: translateY(-1px);
        }

        .hero-dots .dot.is-active {
            background: linear-gradient(90deg, var(--orange-500), var(--red-600));
            width: 34px;
        }

        /* ---------------- HERO GRID + CARDS ---------------- */
        .hero-grid {
            display: grid;
            grid-template-columns: 1.15fr .85fr;
            gap: 18px;
            align-items: stretch;
        }

        /* Card Izquierdo */
        .hero-card {
            position: relative;
            overflow: hidden;
            padding: 18px;
            border-radius: 16px;
            max-width: 760px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            box-shadow: 0 18px 44px rgba(0, 0, 0, .12);
        }

        .hero-card:before {
            content: "";
            position: absolute;
            inset: -40px -60px auto auto;
            width: 220px;
            height: 220px;
            background:
                radial-gradient(circle at 30% 30%, rgba(250, 163, 26, .35), transparent 62%),
                radial-gradient(circle at 70% 70%, rgba(219, 35, 40, .25), transparent 60%);
            transform: rotate(25deg);
            pointer-events: none;
        }

        .kicker {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(250, 164, 26, 0.35);
            border: 1px solid rgba(250, 163, 26, .22);
            font-weight: 800;
            font-size: 13px;
            color: #ffffff;
            position: relative;
            z-index: 1;
        }

        .hero-card h1 {
            margin: 14px 0 10px;
            font-size: clamp(24px, 2.8vw, 38px);
            line-height: 1.08;
            letter-spacing: -.04em;
            position: relative;
            z-index: 1;
            color: #ffffff;
            text-shadow: 0 1px 0 rgba(255, 255, 255, .35);
        }

        .lead {
            margin: 0 0 18px;
            color: #ffffff;
            font-size: 14px;
            position: relative;
            z-index: 1;
            max-width: 62ch;
        }

        .cta-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }

        /* Card Derecho */
        .quick {
            position: relative;
            overflow: hidden;
            padding: 18px;
            color: #E9E9E9;
            border-radius: 16px;
            max-width: 520px;
            background: linear-gradient(180deg,
                    rgba(16, 28, 36, .34),
                    rgba(16, 28, 36, .22));
            border: 1px solid rgba(255, 255, 255, .14);
            box-shadow: 0 18px 42px rgba(0, 0, 0, .18);
        }

        .quick:before {
            content: "";
            position: absolute;
            inset: auto -90px -110px auto;
            width: 260px;
            height: 260px;
            background:
                radial-gradient(circle at 35% 35%, rgba(250, 163, 26, .35), transparent 60%),
                radial-gradient(circle at 70% 70%, rgba(219, 35, 40, .28), transparent 62%);
            transform: rotate(-16deg);
            opacity: .85;
            pointer-events: none;
        }

        .quick h3 {
            margin: 0 0 10px;
            font-size: 16px;
            position: relative;
            z-index: 1;
            letter-spacing: -.01em;
        }

        .quick .qgrid {
            display: grid;
            gap: 10px;
            position: relative;
            z-index: 1;
        }

        .qitem {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 12px 12px;
            border-radius: 14px;
            background: rgba(250, 164, 26, 0.1);
            border: 1px solid rgba(255, 255, 255, .10);
            transition: transform .15s ease, background .15s ease, border-color .15s ease;
        }

        .qitem:hover {
            transform: translateY(-2px);
            background: rgba(255, 255, 255, .10);
            border-color: rgba(255, 255, 255, .16);
        }

        .qitem .lbl {
            font-weight: 800;
            letter-spacing: -.01em;
        }

        .qitem .tag {
            font-size: 12px;
            font-weight: 800;
            padding: 6px 10px;
            border-radius: 999px;
            background: rgba(250, 163, 26, .18);
            border: 1px solid rgba(250, 163, 26, .28);
            color: #ffe0b0;
            white-space: nowrap;
        }

        /* ---------------- SECTIONS ---------------- */
        section {
            padding: 34px 0
        }

        .section-head {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 14px;
        }

        .section-head h2 {
            margin: 0;
            font-size: clamp(20px, 2.1vw, 28px);
            letter-spacing: -.02em;
        }

        .section-head p {
            margin: 0;
            color: var(--gray-600);
            max-width: 70ch;
        }

        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px
        }

        .card {
            border-radius: var(--radius-lg);
            background: #fff;
            border: 1px solid rgba(0, 0, 0, .06);
            box-shadow: var(--shadow-sm);
            padding: 18px;
        }

        .card h3 {
            margin: 0 0 8px;
            font-size: 16px
        }

        .muted {
            color: var(--gray-600)
        }

        .list {
            margin: 10px 0 0;
            padding: 0;
            list-style: none;
            display: grid;
            gap: 10px;
        }

        .list li {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 12px;
            border-radius: 14px;
            background: var(--gray-100);
            border: 1px solid rgba(0, 0, 0, .06);
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 3px;
            margin-top: 6px;
            background: linear-gradient(135deg, var(--red-600), var(--orange-500));
            flex: 0 0 10px;
        }

        /* People */
        .people {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 12px
        }

        .person {
            border-radius: 16px;
            border: 1px solid rgba(0, 0, 0, .06);
            background: #fff;
            box-shadow: var(--shadow-sm);
            overflow: hidden;
        }

        .ph {
            height: 120px;
            background:
                linear-gradient(135deg, rgba(219, 35, 40, .16), rgba(250, 163, 26, .20)),
                radial-gradient(240px 120px at 20% 40%, rgba(255, 255, 255, .55), transparent 60%);
            display: grid;
            place-items: center;
            color: rgba(0, 0, 0, .55);
            font-weight: 800;
            letter-spacing: -.02em;
        }

        .pbody {
            padding: 12px
        }

        .pname {
            font-weight: 800;
            font-size: 13px;
            line-height: 1.2
        }

        .prole {
            font-size: 12px;
            color: var(--gray-600);
            margin-top: 6px
        }

        /* Reglamento links */
        .links {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px
        }

        .alink {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 14px;
            border-radius: 16px;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, .08);
            box-shadow: var(--shadow-sm);
            transition: transform .15s ease;
        }

        .alink:hover {
            transform: translateY(-1px)
        }

        .badge {
            font-size: 12px;
            font-weight: 800;
            padding: 7px 10px;
            border-radius: 999px;
            background: rgba(219, 35, 40, .10);
            border: 1px solid rgba(219, 35, 40, .22);
            color: var(--red-800);
            white-space: nowrap;
        }

        /* Contact */
        .contact {
            display: grid;
            grid-template-columns: 1.1fr .9fr;
            gap: 16px
        }

        .map {
            border-radius: var(--radius-xl);
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, .06);
            box-shadow: var(--shadow-sm);
            min-height: 320px;
            background: var(--gray-100);
        }

        iframe {
            width: 100%;
            height: 100%;
            border: 0
        }

        footer {
            padding: 26px 0;
            border-top: 1px solid rgba(0, 0, 0, .06);
            background: rgba(255, 255, 255, .8);
        }

        .foot {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
            color: var(--gray-600);
            font-size: 13px;
        }

        /* ---------------- MOBILE ---------------- */
        .mobile {
            display: none
        }

        @media (max-width:1200px) {

            .hero-card,
            .quick {
                max-width: unset
            }
        }

        @media (max-width:980px) {
            nav ul {
                display: none
            }

            .burger {
                display: flex
            }

            .actions .btn-outline {
                display: none
            }

            .hero-grid {
                grid-template-columns: 1fr
            }

            .people {
                grid-template-columns: repeat(2, 1fr)
            }

            .grid-2 {
                grid-template-columns: 1fr
            }

            .contact {
                grid-template-columns: 1fr
            }

            .links {
                grid-template-columns: 1fr
            }

            .hero-arrow {
                display: none
            }

            .hero-overlay {
                background: linear-gradient(180deg, rgba(0, 0, 0, .52), rgba(0, 0, 0, .70));
            }

            .hero-slider {
                min-height: auto;
                padding: 24px 0 56px;
            }

            .mobile {
                display: none;
                padding: 0 0 14px
            }

            .mobile.open {
                display: block
            }

            .mobile a {
                display: block;
                padding: 12px 10px;
                border-radius: 12px;
                font-weight: 800;
                color: var(--gray-800);
            }

            .mobile a:hover {
                background: rgba(0, 0, 0, .05)
            }
        }

        /* =========================
   NOSOTROS (ESTILO IMAGEN)
   Mantiene tu HTML y colores CCITA
========================= */

        .about {
            position: relative;
            padding: 78px 0 58px;
            overflow: hidden;
            background: #fff;
        }

        /* Banda lateral grande (como la imagen) */
        .about::before {
            content: "";
            position: absolute;
            left: 0;
            top: 130px;
            width: 100%;
            height: 320px;
            border-radius: 26px;
            background: linear-gradient(135deg,
                    rgba(250, 163, 26, .22),
                    rgba(219, 35, 40, .16));
            filter: saturate(1.05);
            z-index: 0;
        }

        /* Banda derecha con “glow” suave */
       /* .about::after {
            content: "";
            position: absolute;
            right: -80px;
            top: 110px;
            width: 54%;
            height: 340px;
            border-radius: 32px;
            background:
                radial-gradient(520px 240px at 30% 45%, rgba(250, 163, 26, .22), transparent 60%),
                linear-gradient(135deg, rgba(219, 35, 40, .14), rgba(250, 163, 26, .18));
            opacity: .9;
            z-index: 0;
        }*/

        /* Centrado como referencia */
        .about .container {
            position: relative;
            z-index: 1;
            max-width: 1120px;
            /* más “centrado” como la imagen */
        }

        /* Encabezado centrado */
        .about-head {
            display: flex;
            justify-content: center;
            text-align: center;
            margin-bottom: 26px;
        }

        .about-title {
            max-width: 860px;
        }

        .about-pill {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, .75);
            border: 1px solid rgba(0, 0, 0, .08);
            font-weight: 900;
            font-size: 12px;
            color: rgba(0, 0, 0, .65);
        }

        .ap-dot {
            width: 10px;
            height: 10px;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--orange-500), var(--red-600));
            box-shadow: 0 12px 26px rgba(250, 163, 26, .20);
        }

        .about-title h2 {
            margin: 10px 0 8px;
            font-size: clamp(26px, 2.6vw, 38px);
            letter-spacing: -.02em;
        }

        .about-lead {
            margin: 0;
            color: rgba(0, 0, 0, .60);
            font-weight: 600;
            line-height: 1.55;
        }

        /* Grid centrado y compacto */
        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            justify-content: center;
            align-items: stretch;
            margin-top: 18px;
        }

        /* Card estilo “bloque” con borde suave */
        .about-card {
            border-radius: 14px;
            overflow: hidden;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, .10);
            box-shadow: 0 18px 42px rgba(0, 0, 0, .10);
            transform: translateY(0);
            transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
        }

        .about-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 24px 62px rgba(0, 0, 0, .14);
            border-color: rgba(0, 0, 0, .14);
        }

        /* Media arriba (foto) */
        .about-media {
            height: 200px;
            background-image: var(--bg);
            background-size: cover;
            background-position: center;
            position: relative;
        }

        /* Overlay suave para que la foto se vea pro */
        .about-mediaOverlay {
            position: absolute;
            inset: 0;
            background:
                linear-gradient(180deg, rgba(0, 0, 0, .10), rgba(0, 0, 0, .12));
        }

        /* Título “MISIÓN / AUTONOMÍA” sobre la foto */
        .about-mediaTitle {
            position: absolute;
            left: 18px;
            right: 18px;
            bottom: 14px;
            display: flex;
            justify-content: flex-start;
            z-index: 2;
        }

        /* Chip tipo la imagen (barra oscura) pero con colores CCITA */
        .about-chip {
            display: inline-flex;
            align-items: center;
            padding: 10px 14px;
            border-radius: 10px;
            font-weight: 900;
            letter-spacing: .08em;
            font-size: 12px;
            color: #fff;
            background:
                linear-gradient(90deg, rgba(219, 35, 40, .92), rgba(250, 163, 26, .86));
            box-shadow: 0 18px 44px rgba(0, 0, 0, .22);
        }

        /* Body azul “institucional” con toque del logo */
        .about-body {
            position: relative;
            padding: 18px 18px 18px;
            color: rgba(255, 255, 255, .92);
            background:
                radial-gradient(900px 420px at 20% 10%, rgba(250, 163, 26, .18), transparent 55%),
                radial-gradient(900px 460px at 85% 35%, rgba(219, 35, 40, .14), transparent 60%),
                linear-gradient(180deg, rgba(9, 64, 110, .96), rgba(7, 52, 92, .98));
        }

        /* Texto */
        .about-text {
            margin: 0;
            font-weight: 600;
            line-height: 1.55;
        }

        /* línea divisoria fina (como en referencia) */
        .about-divider {
            height: 1px;
            margin: 14px 0 14px;
            background: rgba(255, 255, 255, .30);
        }

        /* bullets dentro */
        .about-bullets {
            margin: 0;
            padding: 0;
            list-style: none;
            display: grid;
            gap: 10px;
        }

        .about-bullets li {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            padding: 10px 10px;
            border-radius: 10px;
            background: rgba(255, 255, 255, .08);
            border: 1px solid rgba(255, 255, 255, .12);
        }

        .b-dot {
            width: 10px;
            height: 10px;
            border-radius: 3px;
            margin-top: 6px;
            background: linear-gradient(135deg, var(--orange-500), var(--red-600));
            box-shadow: 0 12px 26px rgba(250, 163, 26, .18);
            flex: 0 0 10px;
        }

        /* Ajuste responsive */
        @media (max-width: 980px) {
            .about {
                padding: 56px 0 44px;
            }

            .about::before {
                top: 170px;
                width: 88%;
                height: 260px;
                left: 50%;
                transform: translateX(-50%);
                border-radius: 22px;
                opacity: .75;
            }

            .about::after {
                display: none;
            }

            .about-grid {
                grid-template-columns: 1fr;
            }

            .about-media {
                height: 190px;
            }
        }
    </style>


</head>

<body>
    <!-- Top bar -->
    <div class="topbar">
        <div class="container">
            <div class="inner">
                <div class="meta">
                    <span class="pill">Jr. José de Sucre 765 - 3er Piso, Huaraz - Áncash</span>
                    <span class="pill">☎ 972 495 162</span>
                    <span class="pill">✉ secretariageneralcaa@camaradeancash.org.pe</span>
                </div>
                <div class="pill">Corte Superior de Arbitraje – CCITA</div>
            </div>
        </div>
    </div>

    <!-- Header / Nav -->
    <header>
        <div class="container">
            <div class="nav">
                <a class="brand" href="#inicio" aria-label="Inicio">
                    <div class="logo">
                        <!-- Reemplaza logo.png por tu logo real -->
                        <img src="LOGOCORTE.png" alt="Logo Corte de Arbitraje" onerror="this.style.display='none';this.parentElement.textContent='CA';" />
                    </div>
                    <div class="txt">
                        <div class="t1">Corte Superior de Arbitraje</div>
                        <div class="t2">Cámara de Comercio de Áncash</div>
                    </div>
                </a>

                <nav aria-label="Navegación principal">
                    <ul>
                        <li><a href="#nosotros">Nosotros</a></li>
                        <li><a href="organizacion.php">Organización</a></li>
                        <li><a href="#arbitraje">Arbitraje</a></li>
                        <li><a href="#reglamentos">Reglamentos</a></li>
                        <li><a href="#sig">Sistema Integrado</a></li>
                        <li><a href="#contacto">Contacto</a></li>
                    </ul>
                </nav>

                <div class="actions">
                    <a class="btn btn-outline" href="#reglamentos">Ver reglamentos</a>
                    <a class="btn btn-primary" href="#arbitraje">Ingresar</a>

                    <button class="burger" id="burger" aria-label="Abrir menú">
                        <span></span>
                    </button>
                </div>
            </div>

            <!-- Mobile menu -->
            <div class="mobile" id="mobileMenu">
                <a href="#nosotros">Nosotros</a>
                <a href="#organizacion">Organización</a>
                <a href="#arbitraje">Arbitraje</a>
                <a href="#reglamentos">Reglamentos</a>
                <a href="#sig">Sistema Integrado</a>
                <a href="#contacto">Contacto</a>
            </div>
        </div>
    </header>

    <!-- Hero -->
    <main id="inicio" class="hero hero-slider">
        <!-- SLIDES (fondo) -->
        <div class="hero-slides" aria-hidden="true">
            <div class="hero-slide is-active" style="background-image:url('fondocorte.jpg')"></div>
            <div class="hero-slide" style="background-image:url('plaza.jpg')"></div>
            <div class="hero-slide" style="background-image:url('huaraz.jpg')"></div>
        </div>

        <!-- overlay para legibilidad -->
        <div class="hero-overlay" aria-hidden="true"></div>

        <!-- Controles -->
        <button class="hero-arrow prev" type="button" aria-label="Anterior">‹</button>
        <button class="hero-arrow next" type="button" aria-label="Siguiente">›</button>

        <div class="hero-dots" role="tablist" aria-label="Selector de slide">
            <button class="dot is-active" type="button" aria-label="Slide 1"></button>
            <button class="dot" type="button" aria-label="Slide 2"></button>
            <button class="dot" type="button" aria-label="Slide 3"></button>
        </div>

        <!-- TU CONTENIDO -->
        <div class="container">
            <div class="hero-grid">
                <div class="hero-card">
                    <div class="kicker">Arbitraje institucional | CCITA</div>
                    <h1>Solución de controversias de forma <span style="color:var(--red-600)">célere</span> e <span style="color:var(--orange-500)">imparcial</span>.</h1>
                    <p class="lead">
                        Administramos procesos arbitrales desde el 29 de septiembre de 2015, contribuyendo a decisiones que ayudan a resolver conflictos entre las partes.
                    </p>
                    <div class="cta-row">
                        <a class="btn btn-primary" href="#" title="Enlace real: Ingreso de solicitudes">Ingreso de Solicitudes</a>
                        <a class="btn btn-accent" href="#" title="Enlace real: Ingreso de escritos">Ingreso de Escritos</a>
                        <a class="btn btn-outline" href="#" title="Enlace real: Revisión de expedientes">Revisión de Expedientes</a>
                    </div>

                </div>

                <aside class="quick" aria-label="Accesos rápidos">
                    <h3>Accesos rápidos</h3>
                    <div class="qgrid">
                        <a class="qitem" href="#reglamentos">
                            <span class="lbl">Reglamentos</span>
                            <span class="tag">Vigente 05/03/2025</span>
                        </a>
                        <a class="qitem" href="#arbitraje">
                            <span class="lbl">Cláusula arbitral</span>
                            <span class="tag">Modelo</span>
                        </a>
                        <a class="qitem" href="#arbitros">
                            <span class="lbl">Árbitros (Nómina)</span>
                            <span class="tag">Listado</span>
                        </a>
                        <a class="qitem" href="#" title="Enlace real: Tarifario virtual">
                            <span class="lbl">Tarifario virtual</span>
                            <span class="tag">Calculadora</span>
                        </a>
                    </div>
                </aside>
            </div>
        </div>
    </main>

    <!-- NOSOTROS-->
    <section id="nosotros" class="about">
        <div class="container">

            <div class="about-head">
                <div class="about-title">
                    <span class="about-pill"><span class="ap-dot"></span> ¿Quiénes somos?</span>
                    <h2>Nosotros</h2>
                    <p class="about-lead">
                        La Corte de Arbitraje de la Cámara de Comercio, Industria y Turismo de Áncash (CCITA)
                        contribuye a la solución de controversias mediante la institucionalización del arbitraje.
                    </p>
                </div>
            </div>

            <div class="about-grid">

                <!-- MISIÓN -->
                <article class="about-card about-mision">
                    <div class="about-media" style="--bg:url('huaraz.jpg')">
                        <div class="about-mediaOverlay"></div>
                        <div class="about-mediaTitle">
                            <span class="about-chip">MISIÓN</span>
                        </div>
                    </div>

                    <div class="about-body">
                        <p class="about-text">
                            Desde el 29 de septiembre de 2015 administramos procesos arbitrales de forma célere e imparcial,
                            brindando decisiones que ayudan a solucionar conflictos entre las partes.
                        </p>

                        <div class="about-divider"></div>

                        <ul class="about-bullets">
                            <li><span class="b-dot"></span> Celeridad y eficiencia procesal</li>
                            <li><span class="b-dot"></span> Imparcialidad y confidencialidad</li>
                            <li><span class="b-dot"></span> Enfoque institucional</li>
                        </ul>
                    </div>
                </article>

                <!-- VISIÓN / AUTONOMÍA -->
                <article class="about-card about-autonomia">
                    <div class="about-media" style="--bg:url('plaza.jpg')">
                        <div class="about-mediaOverlay"></div>
                        <div class="about-mediaTitle">
                            <span class="about-chip">AUTONOMÍA</span>
                        </div>
                    </div>

                    <div class="about-body">
                        <p class="about-text">
                            La Corte es funcional y administrativamente autónoma, ejerciendo su función conforme
                            a las leyes y reglamentos arbitrales.
                        </p>

                        <div class="about-divider"></div>

                        <ul class="about-bullets">
                            <li><span class="b-dot"></span> Marco normativo y reglamentos</li>
                            <li><span class="b-dot"></span> Gestión independiente</li>
                            <li><span class="b-dot"></span> Transparencia institucional</li>
                        </ul>
                    </div>
                </article>

            </div>
        </div>
    </section>
   
    <!-- Arbitraje -->
    <section id="arbitraje">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Arbitraje</h2>
                    <p>Servicios, accesos y modelo de cláusula arbitral.</p>
                </div>
            </div>

            <div class="grid-2">
                <div class="card">
                    <h3>Servicios</h3>
                    <ul class="list">
                        <li><span class="dot"></span>
                            <div><b>Ingreso de Solicitudes</b> (crear una cuenta para ingresar documentos). :contentReference[oaicite:10]{index=10}</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Ingreso de Escritos</b>.</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Revisión de Expedientes</b>.</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Tarifario virtual</b> (calculadora). </div>
                        </li>
                    </ul>

                    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:14px">
                        <a class="btn btn-primary" href="#">Ingreso de solicitudes</a>
                        <a class="btn btn-accent" href="#">Ingreso de escritos</a>
                        <a class="btn btn-outline" href="#">Revisión de expedientes</a>
                    </div>
                </div>

                <div class="card">
                    <h3>Cláusula arbitral (modelo)</h3>
                    <p class="muted" style="margin-bottom:10px">Copia y pega este texto en tus contratos:</p>
                    <div style="padding:14px;border-radius:16px;background:var(--gray-100);border:1px solid rgba(0,0,0,.06)">
                        “Todo litigio o controversia derivados o relacionados con este acto jurídico, será resuelto mediante arbitraje
                        de conformidad con los reglamentos arbitrales de la Corte de Arbitraje de la Cámara de Comercio, Industria y Turismo de Ancash,
                        a cuyas normas, administración y decisión se someten las partes y las aceptan en su integridad”.
                    </div>
                    <p class="muted" style="margin-top:10px"></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Reglamentos -->
    <section id="reglamentos">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Reglamentos y documentos</h2>
                    <p>Descarga reglamentos, directivas y marco normativo.</p>
                </div>
            </div>

            <div class="links">
                <a class="alink" href="#" title="Subir PDF y enlazar">
                    <div>
                        <div style="font-weight:800">Reglamento vigente</div>
                        <div class="muted" style="font-size:13px">Vigente desde el 05/03/2025</div>
                    </div>
                    <span class="badge">PDF</span>
                </a>

                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Reglamento antiguo</div>
                        <div class="muted" style="font-size:13px">Año 2015</div>
                    </div>
                    <span class="badge">PDF</span>
                </a>

                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Código de ética</div>
                        <div class="muted" style="font-size:13px">Documento institucional</div>
                    </div><span class="badge">PDF</span>
                </a>
                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Estatuto</div>
                        <div class="muted" style="font-size:13px">Documento institucional</div>
                    </div><span class="badge">PDF</span>
                </a>

                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Guía virtual</div>
                        <div class="muted" style="font-size:13px">Material de apoyo</div>
                    </div><span class="badge">LINK</span>
                </a>
                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Directiva N°01-2020</div>
                        <div class="muted" style="font-size:13px">Directiva</div>
                    </div><span class="badge">PDF</span>
                </a>

                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">Reglamento Ley N°32069</div>
                        <div class="muted" style="font-size:13px">Ley General de Contrataciones Públicas</div>
                    </div><span class="badge">PDF</span>
                </a>
                <a class="alink" href="#">
                    <div>
                        <div style="font-weight:800">D. Leg. N°1071</div>
                        <div class="muted" style="font-size:13px">Decreto Legislativo del Arbitraje</div>
                    </div><span class="badge">PDF</span>
                </a>
            </div>

            <p class="muted" style="margin-top:12px">
                Fuente de la lista:
            </p>
        </div>
    </section>

    <!-- Árbitros / Nómina -->
    <section id="arbitros">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Árbitros (Nómina)</h2>
                    <p>Publicar aquí el listado oficial de árbitros habilitados.</p>
                </div>
            </div>

            <div class="card">
                <p class="muted" style="margin:0">
                    Colocar un buscador y la nómina (por especialidad, ciudad, etc.).

                </p>
            </div>
        </div>
    </section>

    <!-- Sistema Integrado -->
    <section id="sig">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Sistema Integrado de Gestión</h2>
                    <p>Documentos y canales institucionales relacionados a cumplimiento y calidad.</p>
                </div>
            </div>

            <div class="grid-2">
                <div class="card">
                    <h3>Componentes</h3>
                    <ul class="list">
                        <li><span class="dot"></span கொள்ள <div><b>Política antisoborno</b> (acta).
                </div>
                </li>
                <li><span class="dot"></span>
                    <div><b>Certificados</b> (ISO 37001:2016 e ISO 9001:2015).</div>
                </li>
                <li><span class="dot"></span>
                    <div><b>Denuncia / Inquietud</b> (formulario). </div>
                </li>
                <li><span class="dot"></span>
                    <div><b>Licencia de funcionamiento</b>. </div>
                </li>
                </ul>
            </div>

            <div class="card">
                <h3>Comunicados</h3>
                <p class="muted">
                    Publica comunicados oficiales, avisos y actualizaciones normativas.
                </p>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px">
                    <a class="btn btn-outline" href="#">Ver comunicados</a>
                    <a class="btn btn-primary" href="#">Registrar denuncia</a>
                </div>
            </div>
        </div>
        </div>
    </section>

    <!-- Contacto -->
    <section id="contacto">
        <div class="container">
            <div class="section-head">
                <div>
                    <h2>Contacto</h2>
                    <p>Ubicación, teléfonos y correos institucionales.</p>
                </div>
            </div>

            <div class="contact">
                <div class="map" aria-label="Mapa">
                    <!-- Reemplaza el src por el mapa real de Google Maps embebido -->
                    <iframe
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                        src="https://www.google.com/maps?q=Jr.%20Jos%C3%A9%20de%20Sucre%20765%20Huaraz%20Ancash&output=embed">
                    </iframe>
                </div>

                <div class="card">
                    <h3>Datos</h3>
                    <ul class="list">
                        <li><span class="dot"></span>
                            <div><b>Dirección:</b> Jr. José de Sucre 765 - 3er Piso, Huaraz - Áncash - Perú.</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Teléfono:</b> 972495162.</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Correo:</b> secretariageneralcaa@camaradeancash.org.pe</div>
                        </li>
                        <li><span class="dot"></span>
                            <div><b>Correo:</b> centrodearbitrajedeancash@camaradeancash.org.pe</div>
                        </li>
                    </ul>

                    <div style="margin-top:14px; display:grid; gap:10px">
                        <a class="btn btn-primary" href="mailto:secretariageneralcaa@camaradeancash.org.pe">Escribir a Secretaría General</a>
                        <a class="btn btn-outline" href="mailto:centrodearbitrajedeancash@camaradeancash.org.pe">Escribir al Centro de Arbitraje</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="foot">
                <div style="display:flex; align-items:center; gap:10px">
                    <span style="width:10px;height:10px;border-radius:3px;background:linear-gradient(135deg,var(--red-600),var(--orange-500));display:inline-block"></span>
                    <span>© <span id="year"></span> Corte Superior de Arbitraje – CCITA</span>
                </div>
                <div>Desing by GIRALDO</div>
            </div>
        </div>
    </footer>
    <!-- Floating buttons -->
    <div class="wa">
        <button class="fab" id="toTop" title="Volver arriba" aria-label="Volver arriba">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 5l-7 7M12 5l7 7" />
                <path d="M12 5v14" />
            </svg>
        </button>

        <button class="fab" id="fabWhats" title="WhatsApp" aria-label="WhatsApp">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.5 11.5a8.5 8.5 0 1 1-16.6 3.4L3 21l6.3-1.8a8.46 8.46 0 0 1-3.4-6.7" />
                <path d="M8.7 8.8c.2-.5.4-.5.7-.5h.6c.2 0 .4.1.5.4l.7 1.8c.1.3.1.5-.1.7l-.4.5c-.1.2-.2.3-.1.5.2.7 1.3 2.3 2.8 3 .5.2.8.2 1.1-.1l.5-.6c.2-.2.4-.3.7-.2l2 .7c.3.1.4.3.4.5 0 .8-.4 1.6-1 2-.6.4-1.4.5-2.2.3-2.3-.6-4.7-2.7-6-4.7-.9-1.4-1.3-2.8-.9-3.8z" />
            </svg>
        </button>
    </div>

    <script>
        // Año en footer (seguro)
        const yearEl = document.getElementById("year");
        if (yearEl) yearEl.textContent = new Date().getFullYear();

        // ===============================
        // Back to top (aparece al bajar)
        // ===============================
        const toTop = document.getElementById("toTop");
        const header = document.querySelector("header");

        const getHeaderOffset = () => {
            const h = header?.offsetHeight || 0;
            const topbar = document.querySelector(".topbar");
            const tb = topbar?.offsetHeight || 0;
            return h + tb + 10; // +10 px de aire
        };

        const toggleToTop = () => {
            if (!toTop) return;
            const show = window.scrollY > 450;
            toTop.classList.toggle("show", show);
        };

        window.addEventListener("scroll", toggleToTop, {
            passive: true
        });
        toggleToTop();

        toTop?.addEventListener("click", () => {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });

        // ==================================
        // Burger / mobile menu (más pro)
        // ==================================
        const burger = document.getElementById("burger");
        const mobileMenu = document.getElementById("mobileMenu");

        const openMobile = () => mobileMenu?.classList.add("open");
        const closeMobile = () => mobileMenu?.classList.remove("open");
        const toggleMobile = () => mobileMenu?.classList.toggle("open");

        burger?.addEventListener("click", (e) => {
            e.stopPropagation();
            toggleMobile();
        });

        // cerrar al click fuera
        document.addEventListener("click", (e) => {
            if (!mobileMenu?.classList.contains("open")) return;
            const inside = mobileMenu.contains(e.target) || burger?.contains(e.target);
            if (!inside) closeMobile();
        });

        // cerrar con ESC
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") closeMobile();
        });

        // cerrar si vuelves a desktop
        window.addEventListener("resize", () => {
            if (window.innerWidth > 980) closeMobile();
        }, {
            passive: true
        });

        // ==================================
        // Smooth scroll con offset del header
        // ==================================
        document.querySelectorAll('a[href^="#"]').forEach((a) => {
            a.addEventListener("click", (e) => {
                const id = a.getAttribute("href");
                if (!id || id === "#") return;

                const el = document.querySelector(id);
                if (!el) return;

                e.preventDefault();
                closeMobile();

                const y = el.getBoundingClientRect().top + window.pageYOffset - getHeaderOffset();
                window.scrollTo({
                    top: y,
                    behavior: "smooth"
                });
            });
        });

        // ==================================
        // HERO SLIDER PRO
        // ==================================
        (() => {
            const hero = document.querySelector(".hero-slider");
            if (!hero) return;

            const slides = Array.from(hero.querySelectorAll(".hero-slide"));
            const dots = Array.from(hero.querySelectorAll(".hero-dots .dot"));
            const prev = hero.querySelector(".hero-arrow.prev");
            const next = hero.querySelector(".hero-arrow.next");

            let idx = 0;
            let timer = null;
            const AUTOPLAY_MS = 3000;

            const mark = (activeIndex) => {
                slides.forEach((s, i) => {
                    s.classList.toggle("is-active", i === activeIndex);
                    s.classList.toggle("is-next", i === (activeIndex + 1) % slides.length);
                });
                dots.forEach((d, i) => d.classList.toggle("is-active", i === activeIndex));
            };

            const setActive = (i) => {
                idx = (i + slides.length) % slides.length;

                // fuerza reflow para que el wipe/blur se reinicie bien
                slides.forEach(s => {
                    s.style.transition = "none";
                });
                void hero.offsetHeight;
                slides.forEach(s => {
                    s.style.transition = "";
                });

                mark(idx);
            };

            const stop = () => {
                if (timer) clearInterval(timer);
                timer = null;
            };
            const play = () => {
                stop();
                timer = setInterval(() => setActive(idx + 1), AUTOPLAY_MS);
            };

            prev?.addEventListener("click", () => {
                setActive(idx - 1);
                play();
            });
            next?.addEventListener("click", () => {
                setActive(idx + 1);
                play();
            });
            dots.forEach((d, k) => d.addEventListener("click", () => {
                setActive(k);
                play();
            }));

            // swipe
            let x0 = null;
            hero.addEventListener("touchstart", (e) => {
                x0 = e.touches[0].clientX;
            }, {
                passive: true
            });
            hero.addEventListener("touchend", (e) => {
                if (x0 === null) return;
                const x1 = e.changedTouches[0].clientX;
                const dx = x1 - x0;
                if (Math.abs(dx) > 55) {
                    setActive(dx > 0 ? idx - 1 : idx + 1);
                    play();
                }
                x0 = null;
            }, {
                passive: true
            });

            // pause on hover
            hero.addEventListener("mouseenter", stop);
            hero.addEventListener("mouseleave", play);

            // pausa si pestaña no visible
            document.addEventListener("visibilitychange", () => {
                if (document.hidden) stop();
                else play();
            });

            setActive(0);
            play();
        })();
    </script>


</body>

</html>